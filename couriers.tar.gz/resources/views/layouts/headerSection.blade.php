<header class="header">
    <button type="button" class="navbar-toggle sidebar-toggle" id="toggleSideBar">
        <i class="fa fa-bars" aria-hidden="true"></i>
    </button>
</header>