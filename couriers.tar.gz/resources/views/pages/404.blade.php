404 error
<?php echo session('message'); ?>