@extends('admin.admin')

@section('page')
search
@endSection