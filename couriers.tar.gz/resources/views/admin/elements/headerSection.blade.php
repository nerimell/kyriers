<header class="header">
    <button type="button" class="navbar-toggle sidebar-toggle" id="toggleSideBar">
        <i class="fa fa-bars" aria-hidden="true"></i>
    </button>
    <a href="{{ URL::asset('/') }}" id="goWebSite"><i class="fa fa-sign-out"></i>Перейти на сайт</a>
</header>