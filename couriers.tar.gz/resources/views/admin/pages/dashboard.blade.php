@extends('admin.admin')
@section('page')

    asdasdasd

@endSection