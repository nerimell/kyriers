@extends('layouts.wrapper')

@section('page')
asd
@endSection