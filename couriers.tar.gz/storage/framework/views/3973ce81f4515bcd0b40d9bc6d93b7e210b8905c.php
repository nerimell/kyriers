<?php $__env->startSection('page'); ?>
    <div class="col-md-12">
        <div class="panel panel-default mh900">
            <div class="panel-body">
            <?php echo e(Form::open(['class' => 'form-horizontal', 'method' => 'POST'])); ?>

                <div class="form-title">
                    Конфигурация сервиса
                </div>
                <div class="form-group">
                <label class="col-xs-12 col-sm-5 col-md-4 col-lg-3">Название сайта</label>
                <div class="col-xs-12 col-sm-7 col-md-4 col-lg-4">
                    <input type="text" class="form-control" name="metaTitle" value="<?php echo e($SiteConfigs->SiteMeta->metaTitle); ?>" />
                </div>
                <div class="hidden-xs hidden-sm col-sm-4 col-lg-5 field_desc">выберите как будет называться ваш сайт</div>
                </div>
                <div class="form-group">
                    <label class="col-xs-12 col-sm-5 col-md-4 col-lg-3">Ключевые слова</label>
                    <div class="col-xs-12 col-sm-7 col-md-4 col-lg-4">
                        <input type="text" class="form-control" name="metaKeys" value="<?php echo e($SiteConfigs->SiteMeta->metaKeys); ?>" />
                    </div>
                    <div class="hidden-xs hidden-sm col-sm-4 col-lg-5 field_desc">(Мета ключи) помогают пользователям найти ваш сайт</div>
                </div>
                <div class="form-group">
                    <label class="col-xs-12 col-sm-5 col-md-4 col-lg-3">Описание сайта</label>
                    <div class="col-xs-12 col-sm-7 col-md-4 col-lg-4">
                        <textarea class="form-control" name="metaDesc"><?php echo e($SiteConfigs->SiteMeta->metaDesc); ?></textarea>
                    </div>
                    <div class="hidden-xs hidden-sm col-sm-4 col-lg-5 field_desc">(Мета описание) может заставить пользователя принять решение перейти именно на ваш сайт</div>
                </div>

                <div class="form-title">
                    Настройки Sms.ru
                </div>
                <div class="form-group">
                    <label class="col-xs-12 col-sm-5 col-md-4 col-lg-3">Api идентификатор</label>
                    <div class="col-xs-12 col-sm-7 col-md-4 col-lg-4">
                        <input type="text" class="form-control" name="smsRuId" value="<?php echo e($SiteConfigs->SmsConfigs->smsRuId); ?>" />
                    </div>
                    <div class="hidden-xs hidden-sm col-sm-4 col-lg-5 field_desc">
                        API идентификатор SMS.RU может быть найден в <a href="https://sms.ru/?panel=api">панели управления sms.ru</a>
                    </div>
                </div>



                <div class="form-group">
                    <button type="submit" class="btn btn-purple centered-btn">Сохранить изменения</button>
                </div>
            <?php echo e(Form::close()); ?>

            </div> <!-- Panel-body -->
        </div> <!-- Panel -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>