<?php $__env->startSection('content'); ?>
<div class="verticalWrapper">
<div class="verticalAligner">
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-default">
                <div class="panel-body">
                <div class="loginFirst">
                    <i class="fa fa-bolt" aria-hidden="true"></i>
                    <h5 class="content-group">Вход в систему
                        <span class="display-block">введите ваши данные</span>
                    </h5>
                </div>
                    <form class="form-horizontal" id="loginForm" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <div class="col-md-12">
                                <input id="username" type="text" placeholder="Логин..." class="form-control" name="username" value="">
                                <i class="fa fa-user absLogin" aria-hidden="true"></i>

                                <?php if($errors->has('username')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">

                            <div class="col-md-12">
                                <input id="password" type="password" class="form-control" name="password" placeholder="Пароль..."><i  class="fa fa-lock absLogin" aria-hidden="true"></i>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group">
                            <div class="col-xs-12">
                                <button type="submit" class="btn btn-primary">
                                    Войти <i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
                                </button>


                            </div>
                            <div class="col-xs-12">
                                <a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>">Забыли пароль?</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>