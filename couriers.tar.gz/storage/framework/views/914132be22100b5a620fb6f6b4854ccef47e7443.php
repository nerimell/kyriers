<?php $__env->startSection('page'); ?>
    <div class="col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Список водителей</h3>

            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <?php if($drivers->count()): ?>
                            <div class="table-responsive">
                                <table class="table editable">
                                    <thead>
                                    <tr>
                                        <th>Имя</th>
                                        <th>Email</th>
                                        <th>Телефон</th>
                                        <th>Город</th>
                                        <th>Статус</th>
                                        <th>№ карты</th>
                                        <th>Тариф</th>
                                        <th class="t-a-r"> </th>
                                    </tr>
                                    </thead>
                                    <tbody id="uberDrivers">
                                    <?php foreach($drivers as $driver): ?>
                                        <tr id="<?php echo e($driver->email); ?>">
                                            <td class="driverName"><?php echo e($driver->first_name . ' ' . $driver->last_name); ?></td>
                                            <td class="driverMail"><?php echo e($driver->email); ?></td>
                                            <td class="driverPhone"><?php echo e($driver->phone); ?></td>
                                            <td class="driverCity">
                                            <?php echo e($uberAccounts[$driver->uberAccount]->city); ?>

                                            </td>
                                            <td class="driverStatus">
                                            <?php if($driver->status) { ?>
                                                <i class="fa driverStatusIco status-ok fa-check-circle" aria-hidden="true"></i>
                                            <?php } else { ?>
                                                <i class="fa driverStatusIco status-wrong fa-times-circle-o" aria-hidden="true"></i>
                                            <?php } ?>
                                            </td>
                                            <td class="driverCreditCard">
                                                <?php echo e($driver->creditCard); ?>

                                            </td>
                                            <td class="driverCreditCard">
                                                <?php echo e($driver->rate); ?>

                                            </td>

                                            <td class="t-a-r">
                                                <button type="button" class="editUberDriver toggleableBtn btn">
                                                    ок
                                                </button>
                                                <button type="button" class="editRate transpBtn">
                                                    <i class="fa fa-pencil"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>

                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <?php if($driversCount): ?> {
                            <span class="noUsers">Водители не найдены, вы можете вернуться на <a
                                        href="<?php echo e(URL::asset('/drivers')); ?>">первую страницу</a></span>
                            <?php else: ?>
                                <span class="noUsers">В данный момент нет ни одного водителя</span>
                            <?php endif; ?>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
            <div id="pagination">
                <?php echo e($drivers->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>