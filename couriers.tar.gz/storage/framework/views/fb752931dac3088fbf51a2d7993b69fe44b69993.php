<?php $__env->startSection('content'); ?>
<?php echo $__env->make('elements.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
<?php echo $__env->yieldContent('page'); ?>
</div>
<?php echo $__env->make('elements.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_data'); ?>
<script src="<?php echo e(URL::asset('/js/frontActions.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
<div class="modal fade" id="loginForm" tabindex="-1" role="dialog">
   <div class="modal-dialog" role="document">
   <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
    <h4 class="modal-title" action-type="authorization">Авторизация</h4>
    <h4 class="modal-title" action-type="registration">Регистрация</h4>
   </div>
   <div class="modal-body">
    <?php echo e(Form::open(['class' => 'form-horizontal', 'method' => 'POST', 'action' => 'auth/sendRegistration'])); ?>

    <div class="form-group">
        <input type="text" class="form-control" name="username" placeholder="Введите логин" />
    </div>
    <div class="form-group">
        <input type="email" class="form-control" name="email" placeholder="Введите Email" />
    </div>
    <div class="form-group">
        <input type="text" class="form-control" name="password" placeholder="Введите пароль" />
    </div>
    <div class="form-group">
        <input type="text" class="form-control" name="passwordConfirm" placeholder="Подтвердите пароль"/>
    </div>
    <div class="form-group">
        <input type="text" class="form-control" name="ChooseCity" placeholder="Укажите город"/>
    </div>
    <?php echo e(Form::close()); ?>

   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    <button type="button" class="btn btn-primary">Save changes</button>
   </div>
  </div>
 </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>