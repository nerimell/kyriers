<?php $__env->startSection('page'); ?>
    <div class="col-xs-12 col-lg-6">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Список тарифов</h3>
        </div>
        <div class="panel-body ratesPanel">
            <div class="table-responsive">

                    <table class="table">
                        <thead>
                        <tr>
                            <th>Наименование</th>
                            <th class="ratePercent">% cтавка</th>
                            <th class="t-a-r">Действия</th>
                        </tr>
                        </thead>
                        <tbody id="ratesListTable">
                        <?php if(count($rates)): ?>
                        <?php foreach($rates as $rate): ?>
                            <tr>
                                <td class="rateName"><span class="toggledHide"><?php echo e($rate->name); ?></span><input type="text" class="toggleableInput" value="<?php echo e($rate->name); ?>" /></td>
                                <td class="ratePercent"><span class="toggledHide"><?php echo e($rate->rate); ?></span><input  class="toggleableInput" type="text" maxlength="2" value="<?php echo e($rate->rate); ?>"/></td>
                                <td class="t-a-r">
                                    <button type="button" class="editRateSubmit toggleableBtn btn">
                                        ок
                                    </button><button type="button" class="editRate smBtn btn btn-default">
                                        <i class="fa fa-edit"></i>
                                    </button><button type="button" class="deleteRate smBtn btn btn-danger">
                                        <i class="fa fa-close"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>


            </div>
        </div>
    </div>
    </div>
    <div class="col-xs-12 col-lg-6">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Создать новый тариф</h3>
            </div>
            <div class="panel-body ratesPanel">
                <div class="table-responsive">
                    <form class="form-horizontal col-md-12">
                        <div class="form-group">
                            <input type="text" class="form-control" name="rateName" placeholder="Введите наименование тарифа..." />
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="ratePercent" placeholder="Укажите процентную ставку..." max-length="2"/>
                        </div>
                        <div class="tarBtnWrapper">
                     <button type="button" class="btn btn-success" id="submitNewRate"><i class="fa fa-chevron-left"></i>Создать</button>
                     </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head_data'); ?>
    @parent
    <script src="<?php echo e(URL::asset('/js/rateActions.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>