<?php $__env->startSection('page'); ?>
    <div class="col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Отчет за <?php echo date('Y-m-d'); ?></h3>

            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <?php if(count($reports)): ?>
                            <div class="table-responsive">
                                <table class="table editable">
                                    <thead>
                                    <tr>
                                        <th>Водитель</th>
                                        <th>Сканирован</th>
                                        <th class="t-a-r">Действия</th>
                                    </tr>
                                    </thead>
                                    <tbody id="uberAccountsListActions">
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <span class="noUsers">Отчеты не найдены</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div id="pagination">
               //
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>