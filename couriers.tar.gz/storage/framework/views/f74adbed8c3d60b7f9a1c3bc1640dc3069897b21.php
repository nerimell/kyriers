
<?php $__env->startSection('page'); ?>
<div id="content">
<div id="errorDiv">
<?php echo session()->getId(); ?>
 <?php
    if(session('regMessage')) {
        echo session('regMessage');
    }
 ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.wrapper', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>