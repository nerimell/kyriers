<?php $__env->startSection('content'); ?>
    <div class="main-wrapper">
        <div class="app" id="app">
            <?php echo $__env->make('admin.elements.headerSection', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('admin.elements.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="content forms-page">
                <div class="title-block">
                    <h3 class="title"><?php echo e($componentTitle); ?></h3>
                    <p class="title-description"><?php echo e($componentDesc); ?></p>
                </div>
                <div class="row">
                    <?php echo $__env->yieldContent('page'); ?>
                </div>
            </div>

            <div id="testDiv">

            </div>
            <div id="lastResponse">

            </div>
            <div id="testJson">

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head_data'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/admin/app.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/admin/vendor.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/admin/template.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/admin/overrides.css')); ?>"/>
    <script src="<?php echo e(URL::asset('/js/sidebar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>