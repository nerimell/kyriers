<?php $__env->startSection('page'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Список пользователей</h3>
                    <a href="/users/addUser" class="topRightHeadingButton btn btn-success" id="addUser" type="button"><i class="fa fa-plus"></i>Добавить</a>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <?php if($users->count()): ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>Логин</th>
                                        <th>Почта</th>
                                        <th>Имя</th>
                                        <th class="t-a-r">Действия</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php foreach($users as $user): ?>
                                    <tr>
                                    <input type="hidden" class="userId" value="<?php echo e($user->id); ?>" />
                                    <td class="userLogin"><?php echo e($user->username); ?></td>
                                    <td class="userMail"><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td class="t-a-r">
                                    <?php if($user->id != 1): ?>
                                    <button type="button" class="deleteUser btn btn-danger">
                                        <i class="fa fa-close"></i>
                                    </button>
                                    <?php endif; ?>
                                    </td>
                                    </tr>
                                    <?php endforeach; ?>

                                    </tbody>
                                </table>
                            </div>
                            <?php else: ?>
                            <span class="noUsers">Пользователи не найдены, вы можете вернуться на <a href="<?php echo e(URL::asset('/users/userList')); ?>">первую страницу</a></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div id="pagination">
                <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head_data'); ?>
    @parent
    <script src="<?php echo e(URL::asset('/js/userActions.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>