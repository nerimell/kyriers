<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <div class="app" id="app">
        <?php echo $__env->make('layouts.headerSection', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="content forms-page">
            <div class="title-block">
                <h3 class="title"><?php echo e($componentTitle); ?></h3>
                <p class="title-description"><?php echo e($componentDesc); ?></p>
            </div>
            <div class="row">
                <?php echo $__env->yieldContent('page'); ?>
            </div>
        </div>

        <div id="testDiv">

        </div>
    </div>
</div>

<?php echo $__env->yieldContent('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head_data'); ?>
<script src="<?php echo e(URL::asset('js/timer.js')); ?>"></script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>