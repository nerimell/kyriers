<?php $__env->startSection('page'); ?>
    <div class="col-xs-12 col-lg-6">
        <div class="panel panel-default mh400">
            <div class="panel-heading"><h3 class="panel-title">Настройки</h3></div>
            <div class="panel-body">
            <?php echo Form::open(['class' => 'form-horizontal leftLabels mh']); ?>

                    <div class="form-group">
                        <label class="col-sm-9 control-label">Сбор информации в:</label>
                        <div class="col-sm-3">
                            <input class="form-control" name="parseInTime" maxlength="5" autocomplete="off" value="<?php echo e($scan_time); ?>" placeholder="02:30">
                        </div>
                    </div>
                <div class="form-group">
                    <label class="col-sm-7 control-label">Тариф для новых водителей:</label>
                    <div class="col-sm-5">
                        <select class="AppLabsSelect" name="rateForNew">
                        <?php foreach($rates as $rate): ?>
                        <option value="<?php echo e($rate->id); ?>"><?php echo e($rate->name); ?></option>
                        <?php endforeach; ?>
                        </select>
                        <div class="AppLabsSelectProto">
                            <div class="currentValue">
                                Не выбран
                            </div>
                            <ul>
                                <?php foreach($rates as $rate): ?>
                                    <li data-value="<?php echo e($rate->id); ?>"><?php echo e($rate->name); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
                    <div class="form-group m0">
                        <div class="alert alert-warning">
                            1. Обратите внимание, что сбор информации будет производится по серверному времени!
                            <span class="dib">Текущее серверное время</span>
                            <div class="ServerTime dib mrl10 bold">
                                <div class="timer">
                                <span class="icon"><i class="fa fa-clock-o"></i></span>
                                <span class="hour">
                                <?php  echo date('H'); ?>
                                </span>
                                <span class="delimeter">
                                :
                                </span>
                                <span class="minute">
                                <?php  echo date('i'); ?>
                                </span>
                                <span class="seconds">
                                <?php echo  date('s'); ?>
                                </span>
                                </div>
                            </div>
                            <div class="mt10">
                            2. Система автоматически округлит желаемое время до ближайшего получаса.
                            </div>
                        </div>
                    </div>

                <button type="submit" class="btn fr btn-success">Сохранить</button>
                <?php echo Form::close(); ?>

            </div> <!-- panel-body -->
        </div> <!-- panel -->
    </div>
    <div class="col-xs-12 col-lg-6">
        <div class="panel panel-default mh400">
            <div class="panel-heading"><h3 class="panel-title">Данные последнего массового сканирования</h3></div>
            <div class="panel-body">
                    <div class="form-group">
                        <label>Последнее сканирование:</label>
                        <span class="result fr"><?php echo date('Y-m-d H:i:s'); ?></span>
                    </div>
                    <div class="form-group">
                        <label>Отсканированно аккаунтов:</label>
                        <span class="result fr">3 из 3</span>
                    </div>
                    <div class="form-group">
                        <label>Произошло ошибок:</label>
                        <span class="result fr">0</span>
                    </div>

            </div><!-- panel-body -->
        </div> <!-- panel -->
    </div>
    <div class="col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Управление парсером</h3>

            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <?php if($users->count()): ?>
                            <div class="table-responsive">
                                <table class="table editable">
                                    <thead>
                                    <tr>
                                        <th>Аккаунт</th>
                                        <th>Сканирован</th>
                                        <th class="t-a-r">Действия</th>
                                    </tr>
                                    </thead>
                                    <tbody id="uberAccountsListActions">
                                    <?php foreach($users as $user): ?>
                                        <tr id="<?php echo e($user->email); ?>">
                                            <td class="userMail"><?php echo e($user->email); ?></td>
                                            <td class="ParsedAt">
                                            <?php
                                                if ($user->scanned_at == '0000-00-00') {
                                                    echo '-';
                                                } else {
                                                    echo $user->scanned_at;
                                                }

                                            ?>
                                            </td>
                                            <td class="t-a-r">
                                            <?php
                                            $class = '';
                                            if($currentScanning) {
                                                if(in_array($user->email, $currentScanning)) {
                                                    $class = 'scanning';
                                                }
                                            }
                                            ?>
                                                <button type="button" class="btn scanUberAccount btn-success <?php echo e($class); ?>">
                                                    <span class="default">сканировать</span>
                                                    <span class="active">сканируется <i class="fa fa-spinner fa-spin fa-3x fa-fw"></i></span>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>

                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <?php if($accountsCount): ?> {
                            <span class="noUsers">Аккаунты не найдены, вы можете вернуться на <a
                                        href="<?php echo e(URL::asset('/uberAccounts')); ?>">первую страницу</a></span>
                            <?php else: ?>
                                <span class="noUsers">В данный момент нет привязанных Uber аккаунтов</span>
                            <?php endif; ?>
                        <?php endif; ?>
                    <div class="alert alert-warning">
                        <i class="fa fa-exclamation-triangle extIcon1" aria-hidden="true"></i>Сканирование каждого аккаунта доступно не более чем раз в пол часа.
                    </div>
                    </div>
                </div>
            </div>
            <div id="pagination">
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head_data'); ?>
<script src="<?php echo e(URL::asset('js/parserActions.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/timer.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/app-labsSelect.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <div class="ajaxPreloadWrapper">
    <div class="ajaxPreloadBody">
                    <div class="AjaxPreloadTitle">
                        <span class="main">Пожалуйста подождите</span>
                        <span class="mini">Сканирование может занять до нескольких минут</span>
                    </div>
                    <div class="cssload-container">
                        <div class="cssload-loading"><i></i><i></i><i></i><i></i></div>
                    </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>