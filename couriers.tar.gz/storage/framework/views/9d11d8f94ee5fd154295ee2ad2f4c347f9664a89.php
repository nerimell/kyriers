<?php $__env->startSection('page'); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Список аккаунтов</h3>
                    <button class="topRightHeadingButton btn btn-success" id="addUberAccount" type="button"><i class="fa fa-plus"></i>Добавить</button>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <?php if($users->count()): ?>
                            <div class="table-responsive">
                                <table class="table editable">
                                    <thead>
                                    <tr>
                                        <th>Email</th>
                                        <th>Пароль</th>
                                        <th>Добавлен</th>
                                        <th>Сканирован</th>
                                        <th class="t-a-r">Действия</th>
                                    </tr>
                                    </thead>
                                    <tbody id="uberAccountsListTable">
                                    <?php foreach($users as $user): ?>
                                    <tr>
                                    <input type="hidden" class="userId" value="<?php echo e($user->id); ?>" />
                                    <td class="userMail">
                                        <span class="toggledHide"><?php echo e($user->email); ?></span>
                                        <input type="text" class="toggleableInput" value="<?php echo e($user->email); ?>"/>
                                    </td>
                                    <td class="userPassword">
                                        <span class="toggledHide"><?php echo e($user->password); ?></span>
                                        <input type="text" class="toggleableInput" value="<?php echo e($user->password); ?>"/>
                                    </td>
                                    <td class="createdAt"><?php echo e($user->created_at); ?></td>
                                    <td class="ParsedAt">
                                    <?php
                                    if($user->scanned_at == '0000-00-00') {
                                        echo '-';
                                    } else {
                                        echo $user->scanned_at;
                                    }
                                    ?>
                                    </td>
                                    <td class="t-a-r">
                                        <button type="button" class="editUberAccount transpBtn">
                                            <i class="fa fa-pencil"></i>
                                        </button>
                                    <button type="button" class="deleteUberAccount transpBtn">
                                        <i class="fa fa-close"></i>
                                    </button>
                                    </td>
                                    </tr>
                                    <?php endforeach; ?>

                                    </tbody>
                                </table>
                            </div>
                            <?php else: ?>
                            <?php if($accountsCount): ?> {
                            <span class="noUsers">Аккаунты не найдены, вы можете вернуться на <a href="<?php echo e(URL::asset('/uberAccounts')); ?>">первую страницу</a></span>
                            <?php else: ?>
                            <span class="noUsers">В данный момент нет привязанных Uber аккаунтов</span>
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div id="pagination">
                <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head_data'); ?>
    @parent
    <script src="<?php echo e(URL::asset('/js/comboboxModel.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('/js/uberAccountActions.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <div class="modal fade" id="uberModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Добавление аккаунта Uber</h4>
                </div>

                <div class="modal-body">

                    <div class="form-group">
                        <input class="form-control" type="email" name="email" class="form-control"
                               placeholder="Введите email...">
                    </div>
                    <div class="form-group">
                       <input class="form-control" type="password" name="password" placeholder="Введите пароль...">
                    </div>
                    <div class="form-group">
                        <select class="combobox values_list" name="city" id="city">
                            <?php foreach($cities as $city): ?>
                                <option value="" selected></option>
                                <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                    <button type="button" id="createNewUberAccount" class="btn btn-primary">Создать</button>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>