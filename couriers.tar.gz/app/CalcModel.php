<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use Auth;
use Hash;
use Illuminate\Http\Request;

class CalcModel extends Model
{


        public function getRates() {

        }





}