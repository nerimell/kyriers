$(document).ready(function() {



$('#toggleSideBar').click(function() {
    $('#app').toggleClass('toggledSide');
});































});